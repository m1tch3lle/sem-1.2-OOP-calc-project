package sci.calc;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Sci_calc {

	private JFrame frmCaLcUlAtOr;
	private JTextField txtDisplay;
	
	double firstnum;
	double secondnum;
	double result;
	String operations;
	String answer;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sci_calc window = new Sci_calc();
					window.frmCaLcUlAtOr.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Sci_calc() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCaLcUlAtOr = new JFrame();
		frmCaLcUlAtOr.setTitle("CaLcUlAtOr");
		frmCaLcUlAtOr.setBounds(100, 100, 450, 600);
		frmCaLcUlAtOr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCaLcUlAtOr.getContentPane().setLayout(null);
		
		txtDisplay = new JTextField();
		txtDisplay.setForeground(new Color(0, 0, 0));
		txtDisplay.setBackground(new Color(224, 228, 233));
		txtDisplay.setBounds(10, 10, 416, 60);
		frmCaLcUlAtOr.getContentPane().add(txtDisplay);
		txtDisplay.setColumns(10);
		
		JButton b0 = new JButton("Back");
		b0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String backspace = null;
				if (txtDisplay.getText().length() > 0) {
					StringBuilder strB = new StringBuilder(txtDisplay.getText());
					strB.deleteCharAt(txtDisplay.getText().length() - 1);
					backspace = strB.toString();
					txtDisplay.setText(backspace);
				}
			}
		});
		b0.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0.setForeground(new Color(224, 228, 233));
		b0.setBackground(new Color(61, 73, 88));
		b0.setBounds(10, 100, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0);
		
		JButton b0_1 = new JButton("(");
		b0_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtDisplay.setText("(");
			}
		});
		b0_1.setForeground(new Color(224, 228, 233));
		b0_1.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_1.setBackground(new Color(61, 73, 88));
		b0_1.setBounds(10, 160, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_1);
		
		JButton b0_2 = new JButton("\u03C0");
		b0_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops;
				ops = (3.1415926535897932384626433832795);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_2.setForeground(new Color(224, 228, 233));
		b0_2.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_2.setBackground(new Color(61, 73, 88));
		b0_2.setBounds(10, 220, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_2);
		
		JButton b0_3 = new JButton("Log");
		b0_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = Math.log(ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_3.setForeground(new Color(224, 228, 233));
		b0_3.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_3.setBackground(new Color(61, 73, 88));
		b0_3.setBounds(10, 280, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_3);
		
		JButton b0_4 = new JButton("Sin");
		b0_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = Math.sin(ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_4.setForeground(new Color(224, 228, 233));
		b0_4.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_4.setBackground(new Color(61, 73, 88));
		b0_4.setBounds(10, 340, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_4);
		
		JButton b0_5 = new JButton("Cos");
		b0_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = Math.cos(ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_5.setForeground(new Color(224, 228, 233));
		b0_5.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_5.setBackground(new Color(61, 73, 88));
		b0_5.setBounds(10, 400, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_5);
		
		JButton b0_6 = new JButton("Tan");
		b0_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = Math.tan(ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_6.setForeground(new Color(224, 228, 233));
		b0_6.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_6.setBackground(new Color(61, 73, 88));
		b0_6.setBounds(10, 460, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_6);
		
		JButton b0_7 = new JButton("\u221A");
		b0_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = Math.sqrt(ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_7.setForeground(new Color(224, 228, 233));
		b0_7.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_7.setBackground(new Color(61, 73, 88));
		b0_7.setBounds(95, 100, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_7);
		
		JButton b0_8 = new JButton(")");
		b0_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtDisplay.setText(")");
			}
		});
		b0_8.setForeground(new Color(224, 228, 233));
		b0_8.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_8.setBackground(new Color(61, 73, 88));
		b0_8.setBounds(95, 160, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_8);
		
		JButton b0_9 = new JButton("Exp");
		b0_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstnum = Double.parseDouble(txtDisplay.getText());
				txtDisplay.setText("");
				operations = "Exp";
			}
		});
		b0_9.setForeground(new Color(224, 228, 233));
		b0_9.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_9.setBackground(new Color(61, 73, 88));
		b0_9.setBounds(95, 220, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_9);
		
		JButton b0_10 = new JButton("ln");
		b0_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = Math.log10(ops * ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_10.setForeground(new Color(224, 228, 233));
		b0_10.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_10.setBackground(new Color(61, 73, 88));
		b0_10.setBounds(95, 280, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_10);
		
		JButton b0_11 = new JButton("Sinh");
		b0_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = Math.sinh(ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_11.setForeground(new Color(224, 228, 233));
		b0_11.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_11.setBackground(new Color(61, 73, 88));
		b0_11.setBounds(95, 340, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_11);
		
		JButton b0_12 = new JButton("Cosh");
		b0_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = Math.cosh(ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_12.setForeground(new Color(224, 228, 233));
		b0_12.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_12.setBackground(new Color(61, 73, 88));
		b0_12.setBounds(95, 400, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_12);
		
		JButton b0_13 = new JButton("Tanh");
		b0_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = Math.tanh(ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_13.setForeground(new Color(224, 228, 233));
		b0_13.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_13.setBackground(new Color(61, 73, 88));
		b0_13.setBounds(95, 460, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_13);
		
		JButton b0_14 = new JButton("x^y");
		b0_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = Math.pow(ops, ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_14.setForeground(new Color(224, 228, 233));
		b0_14.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_14.setBackground(new Color(61, 73, 88));
		b0_14.setBounds(180, 100, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_14);
		
		JButton b0_15 = new JButton("9");
		b0_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String iNum = txtDisplay.getText() + b0_15.getText();
				txtDisplay.setText(iNum);
			}
		});
		b0_15.setForeground(new Color(224, 228, 233));
		b0_15.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_15.setBackground(new Color(61, 73, 88));
		b0_15.setBounds(180, 160, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_15);
		
		JButton b0_16 = new JButton("8");
		b0_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String iNum = txtDisplay.getText() + b0_16.getText();
				txtDisplay.setText(iNum);
			}
		});
		b0_16.setForeground(new Color(224, 228, 233));
		b0_16.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_16.setBackground(new Color(61, 73, 88));
		b0_16.setBounds(180, 220, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_16);
		
		JButton b0_17 = new JButton("5");
		b0_17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String iNum = txtDisplay.getText() + b0_17.getText();
				txtDisplay.setText(iNum);
			}
		});
		b0_17.setForeground(new Color(224, 228, 233));
		b0_17.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_17.setBackground(new Color(61, 73, 88));
		b0_17.setBounds(180, 280, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_17);
		
		JButton b0_18 = new JButton("4");
		b0_18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String iNum = txtDisplay.getText() + b0_18.getText();
				txtDisplay.setText(iNum);
			}
		});
		b0_18.setForeground(new Color(224, 228, 233));
		b0_18.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_18.setBackground(new Color(61, 73, 88));
		b0_18.setBounds(180, 340, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_18);
		
		JButton b0_19 = new JButton("1");
		b0_19.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String iNum = txtDisplay.getText() + b0_19.getText();
				txtDisplay.setText(iNum);
			}
		});
		b0_19.setForeground(new Color(224, 228, 233));
		b0_19.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_19.setBackground(new Color(61, 73, 88));
		b0_19.setBounds(180, 400, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_19);
		
		JButton b0_20 = new JButton("0");
		b0_20.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String iNum = txtDisplay.getText() + b0_20.getText();
				txtDisplay.setText(iNum);
			}
		});
		b0_20.setForeground(new Color(224, 228, 233));
		b0_20.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_20.setBackground(new Color(61, 73, 88));
		b0_20.setBounds(180, 460, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_20);
		
		JButton b0_21 = new JButton("x^3");
		b0_21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = (ops * ops * ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_21.setForeground(new Color(224, 228, 233));
		b0_21.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_21.setBackground(new Color(61, 73, 88));
		b0_21.setBounds(265, 100, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_21);
		
		JButton b0_22 = new JButton("x^2");
		b0_22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = (ops * ops);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_22.setForeground(new Color(224, 228, 233));
		b0_22.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_22.setBackground(new Color(61, 73, 88));
		b0_22.setBounds(265, 160, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_22);
		
		JButton b0_23 = new JButton("7");
		b0_23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String iNum = txtDisplay.getText() + b0_23.getText();
				txtDisplay.setText(iNum);
			}
		});
		b0_23.setForeground(new Color(224, 228, 233));
		b0_23.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_23.setBackground(new Color(61, 73, 88));
		b0_23.setBounds(265, 220, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_23);
		
		JButton b0_24 = new JButton("6");
		b0_24.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String iNum = txtDisplay.getText() + b0_24.getText();
				txtDisplay.setText(iNum);
			}
		});
		b0_24.setForeground(new Color(224, 228, 233));
		b0_24.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_24.setBackground(new Color(61, 73, 88));
		b0_24.setBounds(265, 280, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_24);
		
		JButton b0_25 = new JButton("3");
		b0_25.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String iNum = txtDisplay.getText() + b0_25.getText();
				txtDisplay.setText(iNum);
			}
		});
		b0_25.setForeground(new Color(224, 228, 233));
		b0_25.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_25.setBackground(new Color(61, 73, 88));
		b0_25.setBounds(265, 340, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_25);
		
		JButton b0_26 = new JButton("2");
		b0_26.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String iNum = txtDisplay.getText() + b0_26.getText();
				txtDisplay.setText(iNum);
			}
		});
		b0_26.setForeground(new Color(224, 228, 233));
		b0_26.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_26.setBackground(new Color(61, 73, 88));
		b0_26.setBounds(265, 400, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_26);
		
		JButton b0_27 = new JButton(".");
		b0_27.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtDisplay.setText(txtDisplay.getText()+".");
			}
		});
		b0_27.setForeground(new Color(224, 228, 233));
		b0_27.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_27.setBackground(new Color(61, 73, 88));
		b0_27.setBounds(265, 460, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_27);
		
		JButton b0_24_1 = new JButton("\u00B1");
		b0_24_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double ops = Double.parseDouble(String.valueOf(txtDisplay.getText()));
				ops = ops * (-1);
				txtDisplay.setText(String.valueOf(ops));
			}
		});
		b0_24_1.setForeground(new Color(224, 228, 233));
		b0_24_1.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_24_1.setBackground(new Color(61, 73, 88));
		b0_24_1.setBounds(351, 100, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_24_1);
		
		JButton b0_24_2 = new JButton("%");
		b0_24_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstnum = Double.parseDouble(txtDisplay.getText());
				txtDisplay.setText("");
				operations = "%";
			}
		});
		b0_24_2.setForeground(new Color(224, 228, 233));
		b0_24_2.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_24_2.setBackground(new Color(61, 73, 88));
		b0_24_2.setBounds(350, 160, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_24_2);
		
		JButton b0_24_3 = new JButton("+");
		b0_24_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstnum = Double.parseDouble(txtDisplay.getText());
				txtDisplay.setText("");
				operations = "+";
			}
		});
		b0_24_3.setForeground(new Color(224, 228, 233));
		b0_24_3.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_24_3.setBackground(new Color(61, 73, 88));
		b0_24_3.setBounds(350, 220, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_24_3);
		
		JButton b0_24_4 = new JButton("-");
		b0_24_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstnum = Double.parseDouble(txtDisplay.getText());
				txtDisplay.setText("");
				operations = "-";
			}
		});
		b0_24_4.setForeground(new Color(224, 228, 233));
		b0_24_4.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_24_4.setBackground(new Color(61, 73, 88));
		b0_24_4.setBounds(350, 280, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_24_4);
		
		JButton b0_24_5 = new JButton("*");
		b0_24_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstnum = Double.parseDouble(txtDisplay.getText());
				txtDisplay.setText("");
				operations = "*";
			}
		});
		b0_24_5.setForeground(new Color(224, 228, 233));
		b0_24_5.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_24_5.setBackground(new Color(61, 73, 88));
		b0_24_5.setBounds(350, 340, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_24_5);
		
		JButton b0_24_6 = new JButton("/");
		b0_24_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				firstnum = Double.parseDouble(txtDisplay.getText());
				txtDisplay.setText("");
				operations = "/";
			}
		});
		b0_24_6.setForeground(new Color(224, 228, 233));
		b0_24_6.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_24_6.setBackground(new Color(61, 73, 88));
		b0_24_6.setBounds(351, 400, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_24_6);
		
		JButton b0_24_7 = new JButton("=");
		b0_24_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String answer;
				secondnum = Double.parseDouble(txtDisplay.getText());
				if (operations == "+") {
					result = firstnum + secondnum;
					answer = String.format("%.2f", result);
					txtDisplay.setText(answer);
				} else if (operations == "-") {
					result = firstnum - secondnum;
					answer = String.format("%.2f", result);
					txtDisplay.setText(answer);
				} else if (operations == "*") {
					result = firstnum * secondnum;
					answer = String.format("%.2f", result);
					txtDisplay.setText(answer);
				} else if (operations == "/") {
					result = firstnum / secondnum;
					answer = String.format("%.2f", result);
					txtDisplay.setText(answer);
				}
			}
		});
		b0_24_7.setForeground(new Color(224, 228, 233));
		b0_24_7.setFont(new Font("Lucida Bright", Font.BOLD | Font.ITALIC, 15));
		b0_24_7.setBackground(new Color(61, 73, 88));
		b0_24_7.setBounds(351, 460, 75, 50);
		frmCaLcUlAtOr.getContentPane().add(b0_24_7);
		
		JButton bC = new JButton("C");
		bC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtDisplay.setText("");
			}
		});
		bC.setForeground(new Color(64, 128, 128));
		bC.setBackground(new Color(255, 128, 0));
		bC.setBounds(10, 520, 416, 21);
		frmCaLcUlAtOr.getContentPane().add(bC);
	}

}
