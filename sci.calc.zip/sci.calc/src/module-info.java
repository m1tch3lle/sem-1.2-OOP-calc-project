/**
 * 
 */
/**
 * 
 */
module sci.calc {
	requires java.desktop;
}